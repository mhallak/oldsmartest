/*********************************************************************
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2013, Open Source Robotics Foundation
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of the Open Source Robotics Foundation
 *     nor the names of its contributors may be
 *     used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *********************************************************************/

/**
 *  \author Dave Coleman
 *  \desc   Example ROS plugin for Gazebo
 */

#include "deepsea_thrust_plugin.h"
#include <ros/ros.h>
#include <stdio.h>
#include <iostream>
#include <cstring>
#include <string>

namespace gazebo
{
// Register this plugin with the simulator
GZ_REGISTER_MODEL_PLUGIN(DeepseaThrustPlugin);

////////////////////////////////////////////////////////////////////////////////
// Constructor
DeepseaThrustPlugin::DeepseaThrustPlugin()
{
	  this->msg_.data = 0;
}

////////////////////////////////////////////////////////////////////////////////
// Destructor
DeepseaThrustPlugin::~DeepseaThrustPlugin()
{
	  event::Events::DisconnectWorldUpdateBegin(this->update_connection_);

	  // Custom Callback Queue
	  this->queue_.clear();
	  this->queue_.disable();
	  this->rosnode_->shutdown();
	  this->callback_queue_thread_.join();

	  delete this->rosnode_;
}

void DeepseaThrustPlugin::UpdateForce(const std_msgs::Float64::ConstPtr& _msg)
{
  this->msg_.data = _msg->data;
}

////////////////////////////////////////////////////////////////////////////////
// Load the controller
void DeepseaThrustPlugin::Load( physics::ModelPtr _parent, sdf::ElementPtr _sdf )
{
	  this->world_ = _parent->GetWorld();
	  this->model_ = _parent;
  	 // load parameters
	  this->robot_namespace_ = "";
	  if (_sdf->HasElement("robotNamespace"))
	    this->robot_namespace_ = _sdf->GetElement("robotNamespace")->Get<std::string>() + "/";

	  if (!_sdf->HasElement("linkName"))
	  {
	    ROS_FATAL("thrust plugin missing <linkName>, cannot proceed");
	    return;
	  }
	  else
		  this->link_ = this->model_->GetLink(_sdf->GetElement("linkName")->GetValueString());

	  if (!this->link_)
	  {
	    ROS_FATAL("thrust plugin error: link named: %s does not exist\n",_sdf->GetElement("linkName")->GetValueString().c_str());
	    return;
	  }

	  if (!_sdf->HasElement("topicName"))
	  {
	    ROS_FATAL("hrust plugin missing <topicName>, cannot proceed");
	    return;
	  }
	  else
	    this->topic_name_ = _sdf->GetElement("topicName")->Get<std::string>();


	  // Make sure the ROS node for Gazebo has already been initialized
	  if (!ros::isInitialized())
	  {
	    ROS_FATAL_STREAM("A ROS node for Gazebo has not been initialized, unable to load plugin. "
	      << "Load the Gazebo system plugin 'libgazebo_ros_api_plugin.so' in the gazebo_ros package)");
	    return;
	  }

	  this->rosnode_ = new ros::NodeHandle(this->robot_namespace_);

	  // Custom Callback Queue
	  ros::SubscribeOptions so = ros::SubscribeOptions::create<std_msgs::Float64>(
	    this->topic_name_,1,
	    boost::bind( &DeepseaThrustPlugin::UpdateForce,this,_1),
	    ros::VoidPtr(), &this->queue_);
	  this->sub_ = this->rosnode_->subscribe(so);

	  // Custom Callback Queue
	  this->callback_queue_thread_ = boost::thread( boost::bind( & DeepseaThrustPlugin::QueueThread,this ) );

  //this->world_->EnablePhysicsEngine(true);
  thrustAxis_.x=0;
  thrustAxis_.y=0;
  thrustAxis_.z=0;

  std::string axis =_sdf->GetElement("thrustAxis")->GetValueString();
  if(axis.compare("z")==0)
  {
	  thrustAxis_.z=_sdf->GetElement("thrustPower")->GetValueDouble();
  }
  if(axis.compare("y")==0)
    {
  	  thrustAxis_.y=_sdf->GetElement("thrustPower")->GetValueDouble();
    }
  if(axis.compare("x")==0)
    {
  	  thrustAxis_.x=_sdf->GetElement("thrustPower")->GetValueDouble();
    }

  //this->link2 = this->model_->GetLink(_sdf->GetElement("propeller")->GetValueString());
  this->update_connection_ = event::Events::ConnectWorldUpdateBegin(
      boost::bind(&DeepseaThrustPlugin::UpdateChild, this));
}

////////////////////////////////////////////////////////////////////////////////
// Update the controller
void DeepseaThrustPlugin::UpdateChild()
{
	this->lock_.lock();
	gazebo::math::Pose pose=this->link_->GetWorldPose();
	this->link_->SetForce(pose.rot*thrustAxis_*this->msg_.data);
	this->lock_.unlock();
}

void DeepseaThrustPlugin::QueueThread()
{
  static const double timeout = 0.01;

  while (this->rosnode_->ok())
  {
    this->queue_.callAvailable(ros::WallDuration(timeout));
  }
}

}
