#ifndef GAZEBO_ROS_TEMPLATE_HH
#define GAZEBO_ROS_TEMPLATE_HH

#include <ros/ros.h>
#include <boost/thread.hpp>
#include <boost/thread/mutex.hpp>

#include <gazebo/physics/physics.hh>
#include <gazebo/transport/TransportTypes.hh>
#include <gazebo/common/Time.hh>
#include <gazebo/common/Plugin.hh>
#include <gazebo/common/Events.hh>

namespace gazebo
{

   class DeepseaBuoyancyPlugin : public ModelPlugin
   {
      /// \brief Constructor
      public: DeepseaBuoyancyPlugin();

      /// \brief Destructor
      public: virtual ~DeepseaBuoyancyPlugin();

      /// \brief Load the controller
      public: void Load( physics::ModelPtr _parent, sdf::ElementPtr _sdf );

      /// \brief Update the controller
      protected: virtual void UpdateChild();


      private: physics::WorldPtr world_;
      private: physics::ModelPtr model_;
      private: event::ConnectionPtr update_connection_;
      private: physics::LinkPtr link_;
      private: boost::mutex lock_;
   };

}

#endif

