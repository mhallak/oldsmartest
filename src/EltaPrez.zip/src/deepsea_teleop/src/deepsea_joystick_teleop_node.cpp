#include "ros/ros.h"
#include "std_msgs/Float64.h"
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <sensor_msgs/Joy.h>


sensor_msgs::Joy lastmsg;
float force=40000;
void joystickCallback(const sensor_msgs::Joy::ConstPtr & msg){
	lastmsg.header.frame_id="ok";
	lastmsg.axes=msg->axes;
	lastmsg.buttons=msg->buttons;
}

void forceCallback(const std_msgs::Float64::ConstPtr & msg){
	force=msg->data;
}


int indexY=-1;
int indexZ=-1;
int indexThrust=-1;

int main(int argc, char **argv)
{
  //Initialize the node and connect to master
  ros::init(argc, argv, "deepsea_joystick_node");

  //generate a node handler to handle all messages
  ros::NodeHandle n;

  n.param("axis_Y",indexY,indexY);
  n.param("axis_Z",indexZ,indexZ);
  n.param("axis_thrust",indexThrust,indexThrust);


  ros::Subscriber joystick_sub=n.subscribe("/joy", 1, &joystickCallback);
  ros::Subscriber force_sub=n.subscribe("/reconfig", 1, &forceCallback);

  ros::Publisher yAxis_pub = n.advertise<std_msgs::Float64>("/deepsea/propeller_yAxis_position_controller/command", 1);
  ros::Publisher zAxis_pub = n.advertise<std_msgs::Float64>("/deepsea/propeller_zAxis_position_controller/command", 1);
  ros::Publisher thruster_pub = n.advertise<std_msgs::Float64>("/deepsea/thruster/command", 1);

  ros::Rate rate(5);


  double yAxis_max=0.6;
  double yAxis_min=-0.6;

  double zAxis_max=0.6;
  double zAxis_min=-0.6;

  double thruster_max=350;
  double thruster_min=-350;

  double yAxis_val=0;
  double zAxis_val=0;
  double thruster_val=0;

std_msgs::Float64 YAxismsg;
std_msgs::Float64 ZAxismsg;
std_msgs::Float64 Thrustmsg;

  while (ros::ok())
  {
    /**
     * This is a message object. You stuff it with data, and then publish it.
     */

    if (lastmsg.header.frame_id.compare("ok")==0) {
	lastmsg.header.frame_id="";
		YAxismsg.data=0.8*lastmsg.axes[indexY];
		ZAxismsg.data=0.8*lastmsg.axes[indexZ];
		Thrustmsg.data=force*lastmsg.axes[indexThrust];
		
        ros::spinOnce();   
    }
    yAxis_pub.publish(YAxismsg);
    zAxis_pub.publish(ZAxismsg);
    thruster_pub.publish(Thrustmsg);
    ros::spinOnce();

  }
 
  return 0;
}
